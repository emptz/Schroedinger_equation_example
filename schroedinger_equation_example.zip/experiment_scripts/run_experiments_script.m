step_size = 0.01;
nr_steps = 20;
%n is the number of grid points in each direction
n = 32;
%d is the dimension of the domain of the Schroedinger equation
d = 10;
%the file name of the second derivative's matrix representation
second_derivative_file_name = '.\experiment_scripts\data_interval_minus8_plus8.txt';
%vector containing the values for the artifical (heuristic) rank increase of the initial value. This does not
%actually change the initial value.
b = 10:10:20;

%reference solution: uses quartered step size
output_file_name = sprintf('autocor_HH_rank_%d_quatered_step_size.txt', b(end));
minimal_example_HH_no_storage(d, n, second_derivative_file_name, b(end), output_file_name, step_size/4, 4*nr_steps);

%compute autocorrelation with the specified rank increases for the inital
%value. This is done once with the specified step size and once with the
%halved step size
for i = 1 : numel(b)
    output_file_name = sprintf('autocor_HH_rank_%d.txt', b(i));
    minimal_example_HH_no_storage(d, n, second_derivative_file_name, b(i), output_file_name, step_size, nr_steps); 

    
    output_file_name = sprintf('autocor_HH_rank_%d_halved_step_size.txt', b(i));
    minimal_example_HH_no_storage(d, n, second_derivative_file_name, b(i), output_file_name, step_size/2, nr_steps*2);
end


autocor_results_table(nr_steps)