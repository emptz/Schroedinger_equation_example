function retval = build_IV(d, n, file_name)
% builds the initial value used in the example in the lubich paper
% d = dimensions, n = degrees of freedom in each dimension
% either all parameters or none at all have to be given
% NOTE: the data file has to be built via the fortran routine with n gridpoints in 1 dimension!!!
if(nargin == 0)
d = 10;
n = 32;
file_name = 'data_interval_minus8_plus8.txt';
end

% read the grid from the file
fileID = fopen(file_name,'r');
formatSpec = '%f';
grid_size = [n, 1];
grid = fscanf(fileID, formatSpec, grid_size);
fclose(fileID);


% build tt tensor
retval = tt_tensor;
retval.d = d;
mode_size = n*ones(d, 1);
retval.n =  mode_size;
ranks = ones(d+1, 1);
retval.r = ranks;

some_core = exp((-(grid - 2).^2)./2);
retval.core = [];
retval.ps = 1;
for i = 1:d
    retval.core = [retval.core; some_core];
    %each core contains only n elements, so the i-th core starts at index
    % (i-1)*n + 1 and ends at i*n
    retval.ps = [retval.ps; i*n + 1];
end
% normalise
retval.core(1:n) = (1/norm(retval))*retval.core(1:n);
end


