function outputArg1 = autocor_results_table(nr_steps)
%takes the autocor values from files and creates a
%table containing the maximum and average deviation for all pairs of files.
%Can handle halved, quatered, and doubled step sizes.

%step 1: read the data

% Get a list of all txt files in the current folder, or subfolders of it.
%https://matlab.fandom.com/wiki/FAQ#How_can_I_process_a_sequence_of_files.3F
fds = fileDatastore('.\Experiment_HH\*.txt', 'ReadFcn', @importdata);
fullFileNames = fds.Files;
numFiles = length(fullFileNames);
data = cell(numFiles, 2);

% Loop over all files and read the data.
for k = 1 : numFiles
    file_name = fullFileNames{k};
    fileID = fopen(file_name,'r');
    fgets(fileID); %skip first line of table
    formatSpec = '%f';
    
    nr_elements = nr_steps;
    %other step sizes come with a different number of elements
    if contains(file_name, 'halved_step_size')
        nr_elements = 2*nr_elements;
    elseif contains(file_name, 'doubled_step_size')
        nr_elements = 1/2*nr_elements;
    elseif contains(file_name, 'quartered_step_size')
        nr_elements = 4*nr_elements;        
    end
    
    %the autocorrelation function file from MCTDH method is somewhat
    %different
    if contains(file_name, 'MCTDH')
        sizeA = [4, nr_elements + 1];
        A = fscanf(fileID,formatSpec,sizeA);
        A = transpose(A);
        A = A(:, 2) + 1i*A(:, 3);
    else
        sizeB = [2, nr_elements + 1];
        A = fscanf(fileID,formatSpec,sizeB);
        A = transpose(A);
        A = A(:, 1) + 1i*A(:, 2);
    end
    fclose(fileID);
    
    %for different step sizes we have to skip some of the elements, because
    %they are associated to time points which are not available for the
    %coarser step size
    if contains(file_name, 'halved_step_size')
      C = zeros(nr_steps + 1, 1);
      C(1) = A(1);
      for m = 1 : nr_steps
          C(1 + m) = A(1 + 2*m);
      end
      A = C;
    elseif contains(file_name, 'quartered_step_size')
      C = zeros(nr_steps + 1, 1);
      C(1) = A(1);
      for m = 1 : nr_steps
          C(1 + m) = A(1 + 4*m);
      end
      A = C;
    end
        
    data{k, 1} = file_name;
    data{k, 2} = A;
end

%shorten names so that the table is a bit easier to read
partialFileNames = cell(numFiles, 1);
for k = 1 : numFiles
    occurences = find(fullFileNames{k} == '\');
    if fullFileNames{k}(occurences(end) + 1) == 'M'
       partialFileNames{k} = fullFileNames{k}(occurences(end):end);
    else
        partialFileNames{k} = fullFileNames{k}(occurences(end)+12:end);
    end
end

%step 2 compare autocorrelation functions

results = cell(numFiles + 1);
results(2:end, 1) = partialFileNames;
results(1, 2:end) = partialFileNames;
for k = 1 : numFiles
    for s = 1 : numFiles
        A = data{k, 2};
        B = data{s, 2};
        
        % ----------------------
        %this is only relevant if one also has doubled_step_sizes
        if contains(data{k,1}, 'doubled_step_size') & ~contains(data{s,1}, 'doubled_step_size')
            C = zeros(nr_steps/2 + 1, 1);
            C(1) = B(1);
            for m = 1 : nr_steps/2
                C(1 + m) = B(1 + 2*m);
            end
            B = C;      
        elseif ~contains(data{k,1}, 'doubled_step_size') & contains(data{s,1}, 'doubled_step_size')
            C = zeros(nr_steps/2 + 1, 1);
            C(1) = A(1);
            for m = 1 : nr_steps/2
                C(1 + m) = A(1 + 2*m);
            end
            A = C;
        end
        % ----------------------       
        
        norms = abs(A-B);
        
        max_norm_dif = max(norms);
        
        average_norm_dif = (1/(nr_steps+1))*sum(norms);
        results{k+1,s+1} = [max_norm_dif, average_norm_dif];
    end
end

outputArg1 = results;
end

