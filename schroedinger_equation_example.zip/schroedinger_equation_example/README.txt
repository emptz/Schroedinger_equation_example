This code computes the autocorrelation function for the solution to the Schroedinger equation with Henon-Heiles potential (as described in my bachelor thesis)
with various ranks used for the initial condition.
The output is a table whose (i,j)-th entry contains the maximum and average deviation between the autocorrelation functions across the computed time points
from two results obtained with initial values of different ranks.
The code uses the TT-Toolbox implementation of the splitting integrator.

Usage:
Put the two folders from this zip archive in the "TT-Toolbox-master" folder. Then execute the "run_experiments_script" found in the "experiment_script" folder.
The current path in Matlab has to be "TT-Toolbox-master". When trying to execute the script with the aforementioned current path, 
Matlab will tell You that the folder "experiment_script" has to be added to the path. You simply have to click "yes".

The step size, number of steps, artificial rank increases of the initial value, and dimension can be changed to other suitable values.
If one wants to change n, the number of grid points in a single dimension, 
one has to provide a suitable matrix representation of the second derivative operator restricted to a n-dimensional subspace.