function H = build_hamiltonian_v2_test(d, n, file_name)
  % this computes the Hamiltonian multiplied by 1i, because 
  % that is the actual operator used to solve the problem dx/dt + H_mod x = 0

  % d = dimensions, n = degrees of freedom in each dimension, lambda is some parameter
  % either all parameters or none at all have to be given 
  setup;
  %the precision used for "rounding" later on
  precision = 1e-14;
  lambda = 0.111803;
    
  % read the 1-dimensional grid [n values] and 2nd derivative matrix wrt grid coordinates [n*n values] from file
  fileID = fopen(file_name,'r');
  formatSpec = '%f';
  sizeA = n*(n+1);
  A = fscanf(fileID,formatSpec,sizeA);
  fclose(fileID);

  deriv = A(n+1:end);
  deriv = 1i*deriv;
  deriv = reshape(deriv, n, n);
  grid = A(1:n);

  % compute the matrix representation of the laplacian and
  % compute the matrix representation of the potential
  
  % first, compute all summands
  dia = diag(grid);
  M = tt_matrix(dia);
  M_1 = -1i*(1/3)*lambda*dia*dia*dia;
  M_2 = tt_matrix(1i*lambda*dia*dia);
  M_3 = 1i*(1/2)*dia*dia;
  
  deriv = -(1/2)*deriv;
  summands = cell(1,d);
  summands{1} = prepare_factors(d,n,tt_matrix(deriv + M_3),1);
  summands{1} = mtkron(summands{1});
  for i=2:d
    summands{i} = prepare_factors(d,n,tt_matrix(deriv + M_1 + M_3),i);
    summands{i} = mtkron(summands{i});
  end
  
  %second term
  summands_2 = cell(1,d-1);
  for i=1:(d-1)
    summands_2{i} = prepare_factors_2(d, n, M_2, M, i, i+1);
    summands_2{i} = mtkron(summands_2{i});
  end

  
  % then combine the summands to obtain the hamiltonian
  H = summands{d};
  for i=1:(d-1)
    H = H + summands{i} + summands_2{i};
  end
  H = round(H, precision);
end

function retval = prepare_factors(d, n, M, k)
  %d dimensions, n mode size (integer, mode size is the same in each dimension), M is the Matrix in TT_matrix-format that is the k-th factor.
  %1 \leq k \leq d
  retval = cell(1,d);
  for i=1:d
    if(i~=k)
      retval{i} = tt_eye(n);
    else
      retval{i} = M;
    end
  end
end

function retval = prepare_factors_2(d, n, M, N, k, l)
  %in this case 2 factors are given
  %d dimensions, n mode size (integer, mode size is the same in each dimension), M is the Matrix in TT_matrix-format that is the k-th factor.
  %1 \leq k, l \leq d and k~= l
  retval = cell(1,d);
  for i=1:d
    if(i~=k && i~=l)
      retval{i} = tt_eye(n);
    elseif(i==k)
      retval{i} = M;
    elseif(i==l)
      retval{i} = N;
    end
  end
end

