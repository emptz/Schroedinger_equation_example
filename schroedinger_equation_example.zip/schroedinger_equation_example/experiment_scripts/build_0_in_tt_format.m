function outputArg1 = build_0_in_tt_format(d, n)
    y = tt_tensor;
    y.d = d;
    mode_size = n*ones(d, 1);
    y.n =  mode_size;
    ranks = ones(d+1, 1);
    y.r = ranks;

    y.core = zeros(d*n, 1);
    y.ps = 1;
    for i = 1:d
        % each core contains only n elements, so the i-th core starts at index
        % (i-1)*n + 1 and ends at i*n
        y.ps = [y.ps; i*n + 1];
    end
    outputArg1 = y;
end

