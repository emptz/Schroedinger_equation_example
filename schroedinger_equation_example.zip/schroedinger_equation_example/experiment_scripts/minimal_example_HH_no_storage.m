function minimal_example_HH_no_storage(d, n, second_derivative_file_name, artifical_rank_increase, output_file_name, step_size, nr_steps)  
    
    y = build_0_in_tt_format(d,n);
    H = build_hamiltonian_v2_test(d,n,second_derivative_file_name);


    
    % compute one time step using the Tensor-Toolbox splitting integrator
    % and then compute the value of the autocorrelation function
    autocor = zeros(1, nr_steps+1);
    initial_value = build_IV(d, n, second_derivative_file_name) + 0*tt_rand(n, d, artifical_rank_increase);
    temp = initial_value;
    autocor(1) = dot(initial_value, initial_value);
    for i = 1:nr_steps
        temp = tt_ksl_ml(temp, H, y, step_size);
        autocor(i+1) = dot(temp, initial_value);
    end
    
    %save results in a file
    print_data = [real(autocor); imag(autocor)];
    fileID = fopen(strcat('.\Experiment_HH\', output_file_name),'w');
    fprintf(fileID,'%15s %15s\n','real part','imaginary part');
    fprintf(fileID,'%12.14f %12.14f\n', print_data);
    fclose(fileID);
end

